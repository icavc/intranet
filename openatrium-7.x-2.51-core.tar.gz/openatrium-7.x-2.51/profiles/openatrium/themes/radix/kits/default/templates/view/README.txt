
This directory should be used to place views template files.
